class Televisao():
    def __init__(self):
        self.canal_exibido = 'Nenhum'
        self.volume = 20

    def selecionar_canal(self):
        canal1 = 'Futura'
        canal2 = 'Animal Planet'

        while True:
            try:
                opcao = int(input(f'Canais disponíveis:\n1. {canal1}\n2. {canal2}\nInforme o número correspondente ao canal selecionado: '))

            except ValueError:
                print('\nERRO!\nOpção inválida!\n')
                continue

            else:
                if opcao == 1:
                    self.canal_exibido = canal1
                    print(f'Canal selecionado: {self.canal_exibido}\n')
                    break
                elif opcao == 2:
                    self.canal_exibido = canal2
                    print(f'Canal selecionado: {self.canal_exibido}\n')
                    break
                else:
                    print('ERRO!\nOpção inválida!\n')
                    continue

    def alterar_volume(self):
        volume = self.volume

        while True:
            try:
                opcao = int(input('Alteração de volume:\n1. Aumentar\n2. Diminuir\nInforme o número correspondente a opção selecionada: '))

            except ValueError:
                print('\nERRO!\nOpção inválida!\n')
                continue

            else:
                while True:
                    print(f'\nVolume = {volume}\n')

                    try:
                        if opcao == 1:
                            novo_volume = int(input('Informe o valor que deseja aumentar: '))
                            volume += novo_volume
                            if volume < 0 or volume > 100:
                                print('\nERRO!\nValor de volume inválido!\n')
                                volume -= novo_volume
                                continue
                            else:
                                self.volume = volume
                                print(f'\nVolume = {self.volume}\n')
                                break

                        if opcao == 2:
                            novo_volume = int(input('Informe o valor que deseja diminuir: '))
                            volume -= novo_volume
                            if volume < 0 or volume > 100:
                                print('\nERRO!\nValor de volume inválido!\n')
                                volume += novo_volume
                                continue
                            else:
                                self.volume = volume
                                print(f'\nVolume = {self.volume}\n')
                                break

                    except ValueError:
                        print('\nERRO!\nOpção inválida!\n')
                        continue

            break

    def info(self):
        print(f'Canal exibido: {self.canal_exibido}\nVolume = {self.volume}\n')