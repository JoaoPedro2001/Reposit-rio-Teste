class Pessoa:
    def __init__(self, nome, idade, altura, peso):
        self.nome = nome
        self.idade = idade
        self.altura = altura
        self.peso = peso

    def mostrar_dados(self):
        print(f'\nNome: {self.nome}\nIdade: {self.idade} anos\nAltura: {self.altura:.2f} m\nPeso: {self.peso:.2f} Kg')

    def envelhecer(self):
        while True:
            try:
                anos = int(input('\nInforme quantos anos deseja envelhecer: '))
            except ValueError:
                print('\nERRO: Valor inválido!\nTente novamente!')
                continue
            else:
                self.idade += anos
                print(f'Idade: {self.idade} anos')
                break

    def engordar(self):
        while True:
            try:
                peso_aumenta = float(input('\nInforme o peso ganho em Kg: '))
            except ValueError:
                print('\nERRO: Valor inválido!\nTente novamente!')
                continue
            else:
                self.peso += peso_aumenta
                print(f'Peso: {self.peso:.2f} Kg')
                break

    def emagrecer(self):
        while True:
            try:
                peso_diminui = float(input('\nInforme o peso perdido em Kg: '))
            except ValueError:
                print('\nERRO: Valor inválido!\nTente novamente!')
                continue
            else:
                self.peso -= peso_diminui
                print(f'Peso: {self.peso:.2f} Kg')
                break