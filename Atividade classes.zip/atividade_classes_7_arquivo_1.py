class Petshop():
    def __init__(self):
        self.racao = 'nenhuma'
        self.banho_tosa = 'nenhuma'
        self.veterinario = 'nenhuma'

    def comprar_racao(self):
        RACAO1 = 'Basic'
        RACAO2 = 'Pro'
        RACAO3 = 'Premium'

        while True:
            try:
                opcao = int(input(f'Opções de ração:\n1. {RACAO1}\n2. {RACAO2}\n3. {RACAO3}\nInforme o número correspondente a opção desejada: '))

            except ValueError:
                print('\nERRO!\nInformação inválida!\n')
                continue

            else:
                if opcao == 1:
                    self.racao = RACAO1
                    print(f'\nRação selecionada: {self.racao}\n')
                    break

                elif opcao == 2:
                    self.racao = RACAO2
                    print(f'\nRação selecionada: {self.racao}\n')
                    break

                elif opcao == 3:
                    self.racao = RACAO3
                    print(f'\nRação selecionada: {self.racao}\n')
                    break

                else:
                    print('\nERRO!\nInformação inválida!\n')
                    continue

    def marcar_banho_tosa(self):
        while True:
            DIA1 = 'Data: 26/03 - Valor: R$ 100,00'
            DIA2 = 'Data: 27/03 - Valor: R$ 100,00'
            DIA3 = 'Data: 28/03 - Valor R$ 120,00'
            try:
                opcao = int(input(f'Dias disponíveis:\n1. {DIA1}\n2. {DIA2}\n3. {DIA3}\nInforme o número correspondente a opção desejada: '))

            except ValueError:
                print('\nERRO!\nInformação inválida!\n')
                continue

            else:
                if opcao == 1:
                    self.banho_tosa = DIA1
                    print(f'\n{self.banho_tosa}\n')
                    break

                elif opcao == 2:
                    self.banho_tosa = DIA2
                    print(f'\n{self.banho_tosa}\n')
                    break

                elif opcao == 3:
                    self.banho_tosa = DIA3
                    print(f'\n{self.banho_tosa}\n')
                    break

                else:
                    print('\nERRO!\nInformação inválida!\n')
                    continue

    def marcar_veterinario(self):
        MEDICO1 = 'Nome: Inireu Siqueira - Dada 22/03'
        MEDICO2 = 'Nome: Maria Joana - Dada 23/03'

        while True:
            try:
                opcao = int(input(f'Médicos disponíveis:\n1. {MEDICO1}\n2. {MEDICO2}\nInforme o número correspondente a opção desejada: '))

            except ValueError:
                print('\nERRO!\nInformação inválida!\n')
                continue

            else:
                if opcao == 1:
                    self.veterinario = MEDICO1
                    print(f'\n{self.veterinario}\n')
                    break

                elif opcao == 2:
                    self.veterinario = MEDICO2
                    print(f'\n{self.veterinario}\n')
                    break

                else:
                    print('\nERRO!\nInformação inválida!\n')
                    continue

    def info(self):
        print(f'Informações:\nRação: {self.racao}\n2.Banho/Tosa: {self.banho_tosa}\n3.Consulta veterinária: {self.veterinario}\n')