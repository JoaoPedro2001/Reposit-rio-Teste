class Funcionario:
    def __init__(self):
        self.nome = 'José Silva'
        self._cpf = 55555555
        self.__salario = 2000.0

    def mostrar_info(self):
        print(f'\nNome: {self.nome}\nCPF: {self._cpf}\nSalário: R$ {self.__salario:,.2f}')