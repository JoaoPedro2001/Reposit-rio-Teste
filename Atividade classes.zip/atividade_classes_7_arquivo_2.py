from atividade_classes_7_arquivo_1 import Petshop

objeto = Petshop()

while True:
    try:
        opcao = int(input('Selecione a atividade:\n1. Mostrar informações\n2. Comprar Ração\n3. Marcar Banho/Tosa\n4. Marcar Veterinário\n5. Fechar Programa\nInforme o número correspondente a opção selecionada: '))

    except ValueError:
        print('\nERRO!\nOpção inválida!\n')
        continue

    else:
        if opcao == 1:
            objeto.info()
            continue

        elif opcao == 2:
            objeto.comprar_racao()
            continue

        elif opcao == 3:
            objeto.marcar_banho_tosa()
            continue

        elif opcao == 4:
            objeto.marcar_veterinario()
            continue

        elif opcao == 5:
            print('Fechando Programa...')
            break

        else:
            print('\nERRO!\nOpção inválida!\n')
            continue