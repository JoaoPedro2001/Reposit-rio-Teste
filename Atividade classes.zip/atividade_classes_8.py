class Frase():
    def __init__(self, frase_escrita, numero_caracteres):
        self.frase = frase_escrita
        self.numero_caracteres = numero_caracteres

    def info(self):
        print(f'Frase: {self.frase}\nNuméro de caracteres: {self.numero_caracteres}')


frase_escrita = input('Escreva a frase:\n')

numero_caracteres = len(frase_escrita) - frase_escrita.count(' ')

objeto = Frase(frase_escrita, numero_caracteres)

objeto.info()