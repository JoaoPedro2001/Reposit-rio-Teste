from atividade_classes_6_arquivo_1 import Televisao

objeto = Televisao()

while True:
    try:
        opcao = int(input('Selecione a atividade:\n1. Mostrar informações\n2. Selecionar canal\n3. Alterar volume\n4. Desligar TV\nInforme o número correspondente a opção selecionada: '))

    except ValueError:
        print('\nERRO!\nOpção inválida!\n')
        continue

    else:
        if opcao == 1:
            objeto.info()
            continue

        elif opcao == 2:
            objeto.selecionar_canal()
            continue

        elif opcao == 3:
            objeto.alterar_volume()
            continue

        elif opcao == 4:
            print('Desligando TV...')
            break

        else:
            print('\nERRO!\nOpção inválida!\n')
            continue