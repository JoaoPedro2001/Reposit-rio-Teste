from atividade_classes_4_arquivo_1 import Funcionario

class Gerente(Funcionario):
    def __init__(self):
        Funcionario.__init__(self)
        self.__senha_autenticacao = '12345'

    def autenticacao(self):
        while True:
            try:
                cpf = int(input('\nCPF: '))
                senha = input('Senha: ')

            except:
                print('\nERRO: Valor de CPF inválido!\nTente novamente!')
                continue

            else:
                if cpf == self._cpf and senha == self.__senha_autenticacao:
                    objeto_pai.mostrar_info()
                    break

                else:
                    print('\nAcesso negado!')
                    continue


while True:
    objeto_pai = Funcionario()
    objeto = Gerente()

    objeto.autenticacao()

    opcao = input('Tentar novamente? [s]im ou [n]ão: ').lower().startswith('s')
    if opcao is True:
        continue
    else:
        break