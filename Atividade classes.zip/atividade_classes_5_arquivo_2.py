from atividade_classes_5_arquivo_1 import Pessoa

while True:
    try:
        nome = input('Informe o nome: ')
        idade = int(input('Informe a idade: '))
        altura = float(input('Informe a altura em metros (m): '))
        peso = float(input('Informe o peso em kilogramas (Kg): '))

    except ValueError:
        print('\nERRO: Valor inválido!\nTente novamente!\n')
        continue

    else:
        objeto = Pessoa(nome, idade, altura, peso)
        break

while True:
    try:
        opcao = int(input('''\nInforme a atividade desejada:
1. Mostrar dados
2. Envelhecer
3. Engordar
4. Emagrecer
Informe o número referente a opção desejada: '''))

    except ValueError:
        print('\nERRO: Valor inválido!\nTente novamente!')
        continue

    else:
        if opcao == 1:
            objeto.mostrar_dados()

        elif opcao == 2:
            objeto.envelhecer()

        elif opcao == 3:
            objeto.engordar()

        elif opcao == 4:
            objeto.emagrecer()

        else:
            print('\nERRO: Opção inválida!\nTente novamente!')
            continue

    opcao2 = input('\nDeseja realizar outra atividade? [s]im ou [n]ão: ').lower().startswith('s')
    if opcao2 is True:
        continue
    else:
        print('\nOperação finalizada!')
        break