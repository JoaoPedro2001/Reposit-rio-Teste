class Bola:
    def __init__(self, cor, circunferencia, material):
        self.cor = cor
        self.circunferencia = circunferencia
        self.material = material

    def trocar_cor(self):
        self.cor = input('Informe a cor da bola: ')

    def mostrar_cor(self):
        print(f'Cor da bola: {self.cor}')

    def mostrar_circunferencia(self):
        print(f'Circunferencia da bola: {self.circunferencia} cm')

    def mostrar_material(self):
        print(f'Material da bola: {self.material}')


while True:
    try:
        cor = input('Informe a cor da bola: ')
        circunferencia = float(input('Informe a circunferencia da bola em centimetros (cm): '))
        material = input('Informe o material da bola: ')

    except ValueError:
        print('ERRO: Valor de circunferencia inválido!\nTente novamente!\n')
        continue

    else:
        objeto = Bola(cor, circunferencia, material)
        break

while True:
    objeto.mostrar_cor()
    objeto.mostrar_circunferencia()
    objeto.mostrar_material()

    opcao = input('Deseja alterar a cor da bola? [s]im ou [n]ão: ').lower().startswith('s')
    if opcao is True:
        objeto.trocar_cor()
        continue

    else:
        print('Programa finalizado!')
        break