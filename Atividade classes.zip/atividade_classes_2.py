class Conta_corrente:
    def __init__(self, numero_da_conta, corretista, saldo):
        self.numero_da_conta = numero_da_conta
        self.corretista = corretista
        self.saldo = saldo

    def mostrar_dados(self):
        print(f'\nN. da conta: {self.numero_da_conta}\nCorretista: {self.corretista}\nSaldo: R$ {self.saldo:,.2f}')

    def fazer_deposito(self):
        while True:
            try:
                deposito = float(input('\nInforme o valor depositado: '))

            except ValueError:
                print('\nValor inválido!\nTente novamente!')
                continue

            else:
                if deposito < 0:
                    print('\nValor inválido!\nTente novamente!')
                    continue
                else:
                    self.saldo += deposito
                    print(f'\nSaldo: R$ {self.saldo:,.2f}')
                    break

    def realizar_saque(self):
        while True:
            try:
                saque = float(input('\nInforme o valor retirado: '))

            except ValueError:
                print('\nValor inválido!\nTente novamente!')
                continue

            else:
                if saque > self.saldo:
                    print('\nValor inválido!\nTente novamente!')
                    continue
                else:
                    self.saldo -= saque
                    print(f'\nSaldo: R$ {self.saldo:,.2f}')
                    break


numero_de_conta = 12345
corretista = 'Irineu da Silva'
saldo = 0.0
objeto = Conta_corrente(numero_de_conta, corretista, saldo)

while True:
    try:
        opcao = int(input('\nO que deseja fazer:\n1. Mostrar dados\n2. Realizar deposito\n3. Realizar saque\nInforme o número correspondente a opção selecionada: '))

    except ValueError:
        print('\nValor inválido!\nTente novamente!')
        continue

    else:
        if opcao == 1:
            objeto.mostrar_dados()

        elif opcao == 2:
            objeto.fazer_deposito()

        elif opcao == 3:
            objeto.realizar_saque()

        else:
            print('\nValor inválido!\nTente novamente!')
            continue

        opcao2 = input('\nDeseja realizar outra atividade? [s]im ou [n]ão: ').lower().startswith('s')
        if opcao2 is True:
            continue

        else:
            print('\nOperação finalizada!')
            break