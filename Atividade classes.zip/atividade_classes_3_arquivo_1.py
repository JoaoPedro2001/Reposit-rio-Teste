class Funcionario:
    def __init__(self, nome, salario):
        self.nome = nome
        self.salario = salario

    def mostrar_nome(self):
        print(f'Nome do funcionário: {self.nome}')

    def mostrar_salario(self):
        print(f'Salario do funcionário: R$ {self.salario:,.2f}')