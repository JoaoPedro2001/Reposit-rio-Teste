from atividade_classes_3_arquivo_1 import Funcionario
while True:
    try:
        nome = input('\nInforme o nome do funcionário: ')
        salario = float(input('\nInforme o salario do funcionário: '))

    except ValueError:
        print('\nERRO: Valor de salário inválido!\nTente novamente!')
        continue

    else:
        objeto = Funcionario(nome, salario)
        break

while True:
    try:
        opcao = int(input('\nInforme a opção desejada:\n1. Mostrar nome\n2. Mostrar salário\nInforme o número referente a opção desejada: '))

    except ValueError:
        print('\nERRO: Valor de salário inválido!\nTente novamente!')
        continue

    else:
        if opcao == 1:
            objeto.mostrar_nome()

        elif opcao == 2:
            objeto.mostrar_salario()

        else:
            print('\nERRO: Valor de salário inválido!\nTente novamente!')
            continue

    opcao2 = input('\nDeseja realizar outra atividade? [s]im ou [n]ão: ').lower().startswith('s')
    if opcao2 is True:
        continue

    else:
        print('\nOperação finalizada!')
        break